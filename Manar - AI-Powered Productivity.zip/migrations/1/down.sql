
DROP INDEX idx_ai_insights_user;
DROP INDEX idx_user_rewards_user;
DROP INDEX idx_user_lesson_progress_lesson;
DROP INDEX idx_user_lesson_progress_user;
DROP INDEX idx_learning_lessons_category;
DROP INDEX idx_focus_sessions_date;
DROP INDEX idx_focus_sessions_user_id;
DROP INDEX idx_users_mocha_user_id;
DROP TABLE ai_insights;
DROP TABLE user_rewards;
DROP TABLE rewards;
DROP TABLE user_lesson_progress;
DROP TABLE learning_lessons;
DROP TABLE learning_categories;
DROP TABLE focus_sessions;
DROP TABLE users;
