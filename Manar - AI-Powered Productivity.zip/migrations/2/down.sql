
DELETE FROM rewards;
DELETE FROM learning_categories;
